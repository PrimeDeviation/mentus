# Reporting security issues in Cytoscape.js

Please report security issues to at least one of the following people:

- Max Franz: maxkfranz@gmail.com
- Dylan Fong: dylanfong.ut@gmail.com
- Christian Lopes: chrtannus@gmail.com
- Mike Kucera: mikekucera@gmail.com
- Alex Pico: alex.pico@gladstone.ucsf.edu
