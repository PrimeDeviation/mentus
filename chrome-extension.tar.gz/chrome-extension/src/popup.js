document.addEventListener('DOMContentLoaded', function() {
    console.log('Popup script loaded');
});
