chrome.runtime.onInstalled.addListener(function() {
    console.log('Background script loaded');
});
